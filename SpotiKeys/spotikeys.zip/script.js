window.addEventListener("keydown", async e => {
	if (e.key === "ArrowLeft") fade(document.querySelector("button[title='Précédent']"));
	if (e.key === "ArrowRight") fade(document.querySelector("button[title='Suivant']"));
});

async function fade(el) {
	el.click();
	el.style.color = "rgb(47, 218, 101)";
	await sleep(1500);
	el.style.color = "rgba(255, 255, 255, 0.6)";
}

async function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}
